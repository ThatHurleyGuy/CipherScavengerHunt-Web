package com.spiteful.cipher.service;

import net.minidev.json.JSONObject;

public interface WebActionCallback {
	public void onCompleted(JSONObject json);
}
