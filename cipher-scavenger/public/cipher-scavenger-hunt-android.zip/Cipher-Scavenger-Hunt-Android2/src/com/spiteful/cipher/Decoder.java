package com.spiteful.cipher;

import java.lang.StringBuilder;

import android.util.Base64;

public class Decoder {
	public static String decodeLevel1(String encoded) {
		return null;
	}

	public static String decodeLevel2(String encoded) {
		return null;
	}

	public static String decodeLevel3(String encoded, String parity) {
		return null;
	}
}
